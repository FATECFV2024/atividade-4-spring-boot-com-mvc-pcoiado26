package com.conectdb.atividade.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;


@Entity
public class nota {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id_nota;
    private String nome_disciplina;
    private Double valor_nota;
    
    public long getIdNota() {
        return id_nota;
    }
    public void setIdNota(long id_nota) {
        this.id_nota = id_nota;
    }
    public String getNomeDisc() {
        return nome_disciplina;
    }
    public void setNomeDisc(String nome_disciplina) {
        this.nome_disciplina = nome_disciplina;
    }
    public Double getNota() {
        return valor_nota;
    }
    public void setNota(Double valor_nota) {
        this.valor_nota = valor_nota;
    }
}