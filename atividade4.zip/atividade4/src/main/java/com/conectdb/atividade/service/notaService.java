package com.conectdb.atividade.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.conectdb.atividade.model.nota;
import com.conectdb.atividade.repository.notaRepository;

@Service
public class notaService implements notaRepository {

    @Autowired
    private notaRepository nR;

    @Override
    public long count() {
        return nR.count();
    }

    @Override
    public void delete(nota entity) {
        nR.delete(entity);
    }

    @Override
    public void deleteAll() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'deleteAll'");
    }

    @Override
    public void deleteAll(Iterable<? extends nota> entities) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'deleteAll'");
    }

    @Override
    public void deleteAllById(Iterable<? extends Long> id_notas) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'deleteAllById'");
    }

    @Override
    public void deleteById(Long id_nota) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'deleteById'");
    }

    @Override
    public boolean existsById(Long id_nota) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'existsById'");
    }

    @Override
    public Iterable<nota> findAll() {
        return nR.findAll();
    }

    @Override
    public Iterable<nota> findAllById(Iterable<Long> id_notas) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'findAllById'");
    }

    @Override
    public Optional<nota> findById(Long id_nota) {
       return nR.findById(id_nota);
    }

    @Override
    public <S extends nota> S save(S entity) {
        return nR.save(entity);
    }

    @Override
    public <S extends nota> Iterable<S> saveAll(Iterable<S> entities) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'saveAll'");
    }

}
