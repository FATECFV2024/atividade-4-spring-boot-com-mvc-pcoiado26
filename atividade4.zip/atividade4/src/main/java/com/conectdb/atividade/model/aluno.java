package com.conectdb.atividade.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;


@Entity
public class aluno {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id_aluno;
    private String nome, curso;
    private int idade;
    private Boolean matricula;
    
    public long getIdAluno() {
        return id_aluno;
    }
    public void setIdAluno(long id_aluno) {
        this.id_aluno = id_aluno;
    }
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public String getCurso() {
        return curso;
    }
    public void setCurso(String curso) {
        this.curso = curso;
    }
    public int getIdade() {
        return idade;
    }
    public void setIdade(int idade) {
        this.idade = idade;
    }
    public Boolean getMatricula() {
        return matricula;
    }
    public void setMatricula(Boolean matricula) {
        this.matricula = matricula;
    }

    
}