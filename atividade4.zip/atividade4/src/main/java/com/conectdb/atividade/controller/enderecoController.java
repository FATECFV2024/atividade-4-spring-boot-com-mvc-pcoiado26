package com.conectdb.atividade.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import com.conectdb.atividade.service.enderecoService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import com.conectdb.atividade.model.endereco;


@RestController
public class enderecoController {
    @Autowired
    private enderecoService es;
    @GetMapping("/listarEnd")
    public List<endereco> listaEnderecos(){
        return (List<endereco>) es.findAll();
    }
    @PostMapping("/criarEnd")
    public endereco criarEnderecos(@RequestBody endereco e){
        endereco novo = es.save(e);
        return novo;
    }
}